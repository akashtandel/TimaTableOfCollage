<html>
    <head>
        <title>AKASH</title>
    </head>
    <body>
        <form method="post">
        <table border="1">
        
            <tbody>
                <tr>
                    <td>ENTER FACULTY NAME:</td>
                    <td>
                        <input type="text" name="fname" />
                    </td>
                </tr>
                <tr>
                    <td>ENTER FF NAME</td>
                    <td>
                        <input type="text" name="ffname" value="" />
                    </td>
                </tr>
                <tr>
                    <td> 
                        <input type="submit" value="SUBMIT" name="submit" />
                    </td>
                     
                    <td> 
                        <input type="submit" value="view" name="view" />
                    </td>
                     
                </tr>
            </tbody>
        </table>
        </form>
    </body>
</html>