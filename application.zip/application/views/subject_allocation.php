<div id="container">
    <form method="post">
	<h1>Subject Allocation </h1>

	<div id="body">
            <table border="0">
                <thead>
                    <tr>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Select Program:-</td>
                       
                        <td>
                            <select  name="pid">
                                 <?php
                                foreach($pdata as $pkey)
                                {
                                    $p_id=$pkey->p_id;
                                    $p_name=$pkey->p_name;
                                    $status=$pkey->status;

                                ?>
                                <option value="<?php echo $p_id;?>"><?php echo $p_name;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                       
                    </tr>
                    <tr>
                        <td>Select Semester:-</td>
                       
                        <td>
                            <select  name="semid">
                                 <?php
                                foreach($sdata as $skey)
                                {
                                    $sem_id=$skey->sem_id;
                                    $p_id=$skey->p_id;
                                    $semester=$skey->semester;
                                    $s_class=$skey->s_class;
                                    $status=$skey->status;

                                ?>
                                <option value="<?php echo $sem_id;?>"><?php echo $semester;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                        
                    </tr>
                   
                    <tr>
                        <td>Select Faculty:-</td>
                       
                        <td>
                            <select  name="fid">
                                 <?php
                                foreach($fdata as $fkey)
                                {
                                    $f_id=$fkey->f_id;
                                    $f_name=$fkey->f_name;
                                    $f_nname=$fkey->f_nname;
                                    $status=$fkey->status;
                                ?>
                                <option value="<?php echo $f_id;?>"><?php echo $f_name;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                        
                    </tr>
                   
                   
                   <tr>
                        <td>Select Subject Code and Name:-</td>
                       
                        <td>
                            <select  name="sid">
                                <?php
                               foreach($cndata as $skey)
                               {
                                   $s_id=$skey->s_id;
                                   $s_code=$skey->s_code;
                                   $s_name=$skey->s_name;
                                   $type=$skey->type;
                                   $status=$skey->status;
                               ?>
                                <option value="<?php echo $s_id;?>"><?php echo $s_code."   ".$s_name;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                   
                   <!-- <tr>
                        <td>Select Extra Lacture:-</td>
                        <td>
                            <select  name="extralac">
                                <option value="">--</option>
                            </select>
                        </td>
                    </tr>-->
                    <tr>
                        <td>
                        <input type="submit" name="subject_allocation" value="submit">
                        <input type="submit" name="load_form" value="Load form">
                        </td>
                    </tr>
                </tbody>
            </table>

	</div>
    </form>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
