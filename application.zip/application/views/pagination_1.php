<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body><center>
         <table border="1">
            <tr>
                <th>Time</th>
                <th>Day</th>
                <th>Subject Code & Name</th>
                <th>Type</th>
                <th>Class</th>
                <th>Program</th>
      
            </tr>
       
        <?php
            foreach($results as $data)
            {
            ?>
            <tr>
                <td><?php echo $data->time1." To ".$data->time1 ;  ?></td>
                <td><?php echo $data->day;  ?></td>
                <td><?php echo $data->s_code."   ";  ?> </td>
                <td><?php echo $data->type;  ?></td>
                <td><?php echo $data->c_name;  ?> </td>
                <td><?php echo $data->p_name;  ?></td>
            </tr>
            <?php
            }
        ?>
            <!--<p><?php  //echo $links;  ?></p>   -->
            <div id="pagination">
                <ul class="tsc_pagination">

                <!-- Show pagination links -->
                    <?php foreach ($links as $link) {
                            echo "<li>".   $link     ."</li>";
                    } ?>
                </ul>
              </div>
    </body>
</html>
