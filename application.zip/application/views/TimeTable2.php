<pre>
    <?php 
    //print_r($table);
     /*echo $tid=$tdata['tid'];
     echo $time1=$tdata['time1'];
     echo $time2=$tdata['time2'];
     echo $day=$tdata['day'];
     echo $f_nname=$tdata['f_nname'];
     echo $s_code=$tdata['s_code'];
     echo $s_name=$tdata['s_name'];
     echo $type=$tdata['type'];
     echo $c_name=$tdata['c_name'];*/
    ?>
</pre>
<center>
<table border="1">
<tr>
	<th colspan="14">SRIMCA</th>
</tr>
<tr>
	<th colspan="14"><?php echo $program['p_name']."   ".$sem['semester'];?> SEM</th>
</tr>
<tr>
	<th>Time</th>
	<th>MONDAY</th>
	<th>TUESDAY</th>
	<th>WEDNESDAY</th>
	<th>THURSDAY</th>
	<th>FRIDAY</th>
	<th>SATURDAY</th>
</tr>
<tr>
	<td>08:30 to 09:25</td>
	<td bgcolor="<?php echo $type['mt1']?>"><center><?php echo $table['mon1']; ?></center></td>
	<td bgcolor="<?php echo $type['tut1']?>"><center><?php echo $table['tue1']; ?></center></td>
	<td bgcolor="<?php echo $type['wt1']?>"><center><?php echo $table['wed1']; ?></center></td>
	<td bgcolor="<?php echo $type['tht1']?>"><center><?php echo $table['thu1']; ?></center></td>
	<td bgcolor="<?php echo $type['frt1']?>"><center><?php echo $table['fri1']; ?></center></td>
	<td bgcolor="<?php echo $type['st1']?>" rowspan="9"><center><b>CIE/Session</b></center></td>
</tr>
<tr>
	<td>09:25 to 10:20</td>
	<td bgcolor="<?php echo $type['mt2']?>"><center><?php echo $table['mon2']; ?></center></td>
	<td bgcolor="<?php echo $type['tut2']?>"><center><?php echo $table['tue2']; ?></center></td>
	<td bgcolor="<?php echo $type['wt2']?>"><center><?php echo $table['wed2']; ?></center></td>
	<td bgcolor="<?php echo $type['tht2']?>"><center><?php echo $table['thu2']; ?></center></td>
	<td bgcolor="<?php echo $type['frt2']?>"><center><?php echo $table['fri2']; ?></center></td>
</tr>
<tr>
	<td>10:20 to 11:15</td>
	<td bgcolor="<?php echo $type['mt3']?>"><center><?php echo $table['mon3']; ?></center></td>
	<td bgcolor="<?php echo $type['tut3']?>"><center><?php echo $table['tue3']; ?></center></td>
	<td bgcolor="<?php echo $type['wt3']?>"><center><?php echo $table['wed3']; ?></center></td>
	<td bgcolor="<?php echo $type['tht3']?>"><center><?php echo $table['thu3']; ?></center></td>
	<td bgcolor="<?php echo $type['frt3']?>"><center><?php echo $table['fri3']; ?></center></td>
</tr>
<tr>
	<td>11:15 to 11:55</td>
	<td colspan="5"><center>BREAK</center></td>
</tr>
<tr>
	<td>11:55 to 12:50</td>
	<td bgcolor="<?php echo $type['mt4']?>"><center><?php echo $table['mon4']; ?></center></td>
	<td bgcolor="<?php echo $type['tut4']?>"><center><?php echo $table['tue4']; ?></center></td>
	<td bgcolor="<?php echo $type['wt4']?>"><center><?php echo $table['wed4']; ?></center></td>
	<td bgcolor="<?php echo $type['tht4']?>"><center><?php echo $table['thu4']; ?></center></td>
	<td bgcolor="<?php echo $type['frt4']?>"><center><?php echo $table['fri4']; ?></center></td>
</tr>
<tr>
	<td>12:50 to 01:45</td>
	<td bgcolor="<?php echo $type['mt5']?>"><center><?php echo $table['mon5']; ?></center></td>
	<td bgcolor="<?php echo $type['tut5']?>"><center><?php echo $table['tue5']; ?></center></td>
	<td bgcolor="<?php echo $type['wt5']?>"><center><?php echo $table['wed5']; ?></center></td>
	<td bgcolor="<?php echo $type['tht5']?>"><center><?php echo $table['thu5']; ?></center></td>
	<td bgcolor="<?php echo $type['frt5']?>"><center><?php echo $table['fri5']; ?></center></td>
</tr>
<tr>
	<td>01:45 to 01:55</td>
	<td colspan="5"><center>BREAK</center></td>
</tr>
<tr>
	<td>01:55 to 02:50</td>
	<td bgcolor="<?php echo $type['mt6']?>"><center><?php echo $table['mon6']; ?></center></td>
	<td bgcolor="<?php echo $type['tut6']?>"><center><?php echo $table['tue6']; ?></center></td>
	<td bgcolor="<?php echo $type['wt6']?>"><center><?php echo $table['wed6']; ?></center></td>
	<td bgcolor="<?php echo $type['tht6']?>"><center><?php echo $table['thu6']; ?></center></td>
	<td><center><?php echo $table['fri6']; ?></center></td>
</tr>
<tr>
	<td>02:50 to 03:45</td>
	<td bgcolor="<?php echo $type['mt7']?>"><center><?php echo $table['mon7']; ?></center></td>
	<td bgcolor="<?php echo $type['tut7']?>"><center><?php echo $table['tue7']; ?></center></td>
	<td bgcolor="<?php echo $type['wt7']?>"><center><?php echo $table['wed7']; ?></center></td>
	<td bgcolor="<?php echo $type['tht7']?>"><center><?php echo $table['thu7']; ?></center></td>
	<td bgcolor="<?php echo $type['frt7']?>"><center><?php echo $table['fri7']; ?></center></td>
</tr>
</table>
