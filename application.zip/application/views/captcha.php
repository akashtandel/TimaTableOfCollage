<html>
<head>
    <title>Captcha</title>
    <script src="<?php echo 'http://localhost/CodeIgniter/index.php/Captcha'; ?>assets/js/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
        $('.refreshCaptcha').on('click', function(){
            $.get('<?php echo 'http://localhost/CodeIgniter/index.php/Captcha/refresh'; ?>', function(data){
                $('#captImg').html(data);
            });
        });
    });
    </script>
</head>
<body>
    <p>Submit the word you see below:</p>
    <p id="captImg"><?php echo $captchaImg; ?></p>
    <a href="http://localhost/CodeIgniter/index.php/Captcha" class="refreshCaptcha" >Refresh</a>
    <form method="post"><br>
        <input type="text" name="captcha" value=""/>
        <input type="submit" name="submit" value="SUBMIT"/>
    </form>
</body>
</html>