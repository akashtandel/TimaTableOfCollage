<html>
    
    <body>
        <form method="post">
            <table border="1">
                <th>
                    <td>f_id</td>
                    <td>f_name</td>
                    <td>ffname</td>
                    <td>status</td>
                    <td>DELETE</td>
                </th>
                <tr>
                    <?php 
                    foreach($f_data as $fkey)
                    {
                        $f_id=$fkey->f_id;
                        $fname=$fkey->f_name;
                        $ffname=$fkey->f_nname;
                        $s=$fkey->status;
                    ?>
                    <td><?php echo $f_id; ?></td>
                    <td><?php echo $fname; ?></td>
                    <td><?php echo $ffname; ?></td>
                    <td><?php echo $s; ?></td>
                    <td><a href="http://localhost/codeIgniter/index.php/exam_con/delete/<?php echo $f_id;?>">DELETE</a></td>
                   
                </tr>
                 <?php
                    }
                    ?>
            </table>
        </form>
    </body>
</html>