<center>
<table border="1">
<tr>
	<th colspan="14">SRIMCA</th>
</tr>
<tr>
	<th colspan="14">MCA 4th SEM</th>
</tr>
<tr>
	<th>Time</th>
	<th>MONDAY</th>
	<th>TUESDAY</th>
	<th>WEDNESDAY</th>
	<th>THURSDAY</th>
	<th>FRIDAY</th>
	<th>SATURDAY</th>
</tr>
