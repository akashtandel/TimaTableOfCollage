<div id="container">
    <form method="post">
	<h1>Insert Semester Wise Subject Details</h1>

	<div id="body">
            <table border="0">
                <thead>
                    <tr>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Select Program:-</td>
                       
                        <td>
                            <select  name="pid">
                                 <?php
                                foreach($pdata as $pkey)
                                {
                                    $p_id=$pkey->p_id;
                                    $p_name=$pkey->p_name;
                                    $status=$pkey->status;

                                ?>
                                <option value="<?php echo $p_id;?>"><?php echo $p_name;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                       
                    </tr>
                    <tr>
                        <td>Select Semester:-</td>
                       
                        <td>
                            <select  name="sid">
                                 <?php
                                foreach($sdata as $skey)
                                {
                                    $sem_id=$skey->sem_id;
                                    $p_id=$skey->p_id;
                                    $semester=$skey->semester;
                                    $s_class=$skey->s_class;
                                    $status=$skey->status;

                                ?>
                                <option value="<?php echo $sem_id;?>"><?php echo $semester;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                        
                    </tr>
                   
                    <!--<tr>
                        <td>Select Faculty And Subject:-</td>
                       
                        <td>
                            <select  name="said">
                                 <?php
                                /*foreach($sadata as $sakey)
                                {
                                    $sa_id=$sakey->sa_id;
                                    $f_name=$sakey->f_name;
                                    $f_nname=$sakey->f_nname;
                                    $s_code=$sakey->s_code;
                                    $s_name=$sakey->s_name;
                                ?>
                               <option value="<?php echo $sa_id;?>"><?php echo $f_name."  ".$s_code." ".$s_name;?></option>
                                 <?php
                                }*/
                                ?>
                            </select>
                        </td>
                        
                    </tr>-->
                    <tr>
                        <td>Subject:-</td>
                       
                        <td>
                            <select  name="said">
                                 <?php
                                foreach($sadata as $sakey)
                                {
                                    $sa_id=$sakey->sa_id;
                                    $f_name=$sakey->f_name;
                                    $f_nname=$sakey->f_nname;
                                    $s_code=$sakey->s_code;
                                    $s_name=$sakey->s_name;
                                ?>
                               <option value="<?php echo $sa_id;?>"><?php echo $s_code." ".$s_name;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                        
                    </tr>
                   
                    <tr>
                        <td>Select Class:-</td>
                        <td>
                            <select  name="cid">
                               
                                <?php
                                foreach($cdata as $ckey)
                                {
                                    $c_id=$ckey->c_id;
                                    $c_name=$ckey->c_name;
                                    $status=$skey->status;
                        
                                ?>
                                <option value="<?php echo $c_id;?>"><?php echo $c_name;?></option>
                                 <?php
                                }
                                ?>
                            </select>
                        </td>
                       
                    </tr>
                   <!--<tr>
                        <td>Select Subject Code and Name:-</td>
                       
                        <td>
                            <select  name="scode">
                                <?php
                               /*foreach($cndata as $skey)
                               {
                                   $s_id=$skey->s_id;
                                   $s_code=$skey->s_code;
                                   $s_name=$skey->s_name;
                                   $type=$skey->type;
                                   $status=$skey->status;*/
                               ?>
                                <option value="<?php //echo $s_code;?>"><?php //echo $s_code."   ".$s_name;?></option>
                                 <?php
                                //}
                                ?>
                            </select>
                        </td>
                    </tr>-->
                    <tr>
                        <td>Select Day:-</td>
                        <td>
                            <select name="day">
                            
                            <option value="monday">monday</option>
                            <option value="tuesday">tuesday</option>
                            <option value="wednesday">wednesday</option>
                            <option value="thursday">thursday</option>
                            <option value="friday">friday</option>
                            <option value="saturday">saturday</option>
                           
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Select Hour:-</td>
                        <td>
                            <select  name="time1">
                                <option value="08:30">08:30</option>
                                <option value="09:25">09:25</option>
                                <option value="10:20">10:20</option>
                                <option value="11:15">11:15</option>
                                <option value="11:55">11:55</option>
                                <option value="12:50">12:50</option>
                                <option value="01:45">01:45</option>
                                <option value="01:55">01:55</option>
                                <option value="02:50">02:50</option>
                               <!-- <option value="03:45">03:45</option>-->
                            </select>
                            to
                            <select  name="time2">
                                <option value="09:25">09:25</option>
                                <option value="10:20">10:20</option>
                                <option value="11:15">11:15</option>
                                <option value="11:55">11:55</option>
                                <option value="12:50">12:50</option>
                                <option value="01:45">01:45</option>
                                <option value="01:55">01:55</option>
                                <option value="02:50">02:50</option>
                                <option value="03:45">03:45</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Select Practical Hours(if any):-</td>
                        <td>
                            <select  name="type">
                                <option value="TH">TH</option>
                                <option value="P">P</option>
                                <option value="PW">PW</option>
                            </select>
                        </td>
                    </tr>
                   <!-- <tr>
                        <td>Select Extra Lacture:-</td>
                        <td>
                            <select  name="extralac">
                                <option value="">--</option>
                            </select>
                        </td>
                    </tr>-->
                    <tr>
                        <td>
                        <input type="submit" name="insert_semester" value="submit">
                        </td>
                    </tr>
                </tbody>
            </table>

	</div>
    </form>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
