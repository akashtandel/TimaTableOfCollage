<tr>
    <?php 
    //print_r($sdata);
    $sid=$sdata['sid'];
    $f_nname=$sdata['f_nname'];
    $p_name=$sdata['p_name'];
    $sem=$sdata['sem'];
    $scode=$sdata['scode'];
    $sname=$sdata['sname'];
?>
    <td><center><?php echo $sid;?></center></td>
    <td><center><?php echo $f_nname;?></center></td>
    <td><center><?php echo $p_name;?></center></td>
    <td><center><?php echo $sem;?></center></td>
    <td><center><?php echo $scode." ".$sname;?></center></td>
    <td><center><a href="http://localhost/CodeIgniter/index.php/TimeTable_con/deletefs/<?php echo $sid;?>"><font color="red">Delete</font></a></center></td>
</tr>