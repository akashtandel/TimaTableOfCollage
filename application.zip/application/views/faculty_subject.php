<form method="post">
    <center> <h1>Faculty Subject </h1></center>
        <center>
            <table border="1">
            <tr>
                    <th>ID</th>
                    <th>FACULTY NAME</th>
                    <th>PROGRAM</th>
                    <th>SEMESTER</th>
                    <th>SUBJECT CODE & NAME</th>
                    <th><font color="red">DELETE</font></th>
            </tr>
            
         
