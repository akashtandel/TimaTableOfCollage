
<table border="1">
    <tr>
    <th>id</th>
    <th>name</th>
    <th>phone</th>
    <th>address</th>
    <!--<th>update</th>
    <th>delete</th>-->
    </tr>
<?php
foreach($data as $row)
{
     $id=$row->id;
     $name=$row->name;
     $phone=$row->phone;
     $add=$row->email;
    ?>
    <tr>
        <td><?php echo $id;?></td>
        <td><?php echo $name;?></td>
        <td><?php echo $phone;?></td>
        <td><?php echo $add;?></td>
        <!--<td><a href="http://localhost/CodeIgniter/index.php/login_con/update/<?php //echo $id;?>">update</a></td>
        <td><a href="http://localhost/CodeIgniter/index.php/login_con/delete/<?php //echo $id;?>">delete</a></td>-->

    </tr>
<?php
}

?>
