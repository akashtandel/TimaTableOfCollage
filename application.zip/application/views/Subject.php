<div id="container">
    <form method="post">
	<h1>Insert Subject</h1>

	<div id="body">
            <table border="0">
                <thead>
                    <tr>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Enter suject code:-</td>
                        <td>
                            <input type="text" name="scode" />
                        </td>
                       
                    </tr>
                    <tr>
                        <td>Enter subject name:-</td>
                       
                        <td>
                            <input type="text" name="sname" />
                        </td>
                        
                    </tr>

                    <tr>
                        <td>
                        <input type="submit" name="subject" value="Insert">
                        </td>
                    </tr>
                </tbody>
            </table>

	</div>
    </form>
	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>' . CI_VERSION . '</strong>' : '' ?></p>
</div>
