<!DOCTYPE html>
<html>
<head></head>
<body><center>
<table border="1">
<tr>
	<th colspan="14">SRIMCA</th>
</tr>
<tr>
	<th colspan="14">MCA 4th SEM</th>
</tr>
<tr>
	<th>Time</th>
	<th>MONDAY</th>
	<th>TUESDAY</th>
	<th>WEDNESDAY</th>
	<th>THURSDAY</th>
	<th>FRIDAY</th>
	<th>SATURDAY</th>
</tr>
<tr>
	<td>08:30 to 09:25</td>
	<td><center>040010424<br>KYP</br>B-203</center></td>
	<td><center>040010426<br>JKT</br>B-203</center></td>
	<td><center>040010425<br>JHT</br>B-203</center></td>
	<td><center>040010427<br>ZMK</br>B-203</center></td>
	<td bgcolor="orange"><center>Elective*(p)</center></td>
	<td rowspan="9"><center><b>CIE/Session</b></center></td>
</tr>
<tr>
	<td>09:25 to 10:20</td>
	<td><center>040010427<br>ZMK</br>B-203</center></td>
	<td><center>040010405<br>(PW)<br>JRS&ZMK<br>B-203</center></td>
	<td><center>Elective*(T)</center></td>
	<td><center>040010405<br>(PW)<br>KYP&JHT<br>B-203</center></td>
	<td><center>Elective*(T)</center></td>
</tr>
<tr>
	<td>10:20 to 11:15</td>
	<td bgcolor="orange"><center>040010426(P)<br>JKT&JRS<br>A-205&A-206</center></td>
	<td><center>040010405<br>(PW)<br>JKT&PRS<br>B-203</center></td>
	<td bgcolor="orange"><center>Elective*(p)</center></td>
	<td><center>040010405<br>(PW)<br>KYP&KBL<br>B-203</center></td>
	<td><center>040010426<br>JKT<br>B-203</center></td>
</tr>
<tr>
	<td>11:15 to 11:55</td>
	<td colspan="5"><center>BREAK</center></td>
</tr>
<tr>
	<td>11:55 to 12:50</td>
	<td><center>Elective*(T)</center></td>
	<td bgcolor="orange"><center>040010424(P)<br>KYP&VRF<br>A-205&A-206</center></td>
	<td><center>040010427<br>ZMK</br>B-203</center></td>
	<td><center>040010424<br>KYP</br>B-203</center></td>
	<td bgcolor="orange"><center>040010424(P)<br>KYP&JHT<br>A-205&A-206</center></td>
</tr>
<tr>
	<td>12:50 to 01:45</td>
	<td><center>040010426<br>JKT<br>B-203</center></td>
	<td bgcolor="orange"><center>040010424(P)<br>KYP&VRF<br>A-205&A-206</center></td>
	<td><center>040010424<br>KYP</br>B-203</center></td>
	<td><center>040010425<br>JHT</br>B-203</center></td>
	<td bgcolor="orange"><center>040010424(P)<br>KYP&VRF<br>A-205&A-206</center></td>
</tr>
<tr>
	<td>01:45 to 01:55</td>
	<td colspan="5"><center>BREAK</center></td>
</tr>
<tr>
	<td>01:55 to 02:50</td>
	<td bgcolor="orange"><center>040010425(P)<br>JHT&KYP<br>A-205&A-206</center></td>
	<td><center>040010425<br>JHT</br>B-203</center></td>
	<td bgcolor="orange"><center>040010425(P)<br>JHT&UYS<br>A-205&A-206</center></td>
	<td bgcolor="orange"><center>040010426(P)<br>JKT&ADP<br>A-205&A-206</center></td>
	<td><center>040010405<br>(PW)<br>ZKM&KBL<br>B-203</center></td>
</tr>
<tr>
	<td>02:50 to 03:45</td>
	<td bgcolor="orange"><center>040010425(P)<br>JHT&KYP<br>A-205&A-206</center></td>
	<td><center>040010424<br>KYP</br>B-203</center></td>
	<td bgcolor="orange"><center>040010425(P)<br>JHT&KKB<br>A-205&A-206</center></td>
	<td bgcolor="orange"><center>040010426(P)<br>JKT&ZKM<br>A-205&A-206</center></td>
	<td><center>040010425<br>JHT</br>B-203</center></td>
</tr>
</table>
</body>
</html>