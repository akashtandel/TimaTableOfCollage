<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TimeTable
 *
 * @author HP
 */
class TimeTable extends CI_Model{

    public function Subject()
    {
        $query=$this->db->get('tbl_subject');
        return $query->result();
    }
    public function Program()
    {
        $query=$this->db->get('tbl_program');
        return $query->result();
    }
    public function Semester()
    {
        $query=$this->db->get('tbl_semester');
        return $query->result();
    }
    public function Subjectcn()
    {
        $query=$this->db->get('tbl_subject');
        return $query->result();
    }
    public function Faculty()
    {
        $query=$this->db->get('tbl_faculty');
        return $query->result();
    }
    public function Clas()
    {
        $query=$this->db->get('tbl_class');
        return $query->result();
    }
    
    public function Subjectallocation()
    {
        $query=$this->db->query('select sa_id,f_name,f_nname,s_code,s_name from tbl_faculty f, tbl_subject s, tbl_subjectallocation sa where f.f_id = sa.sa_id and sa.s_id=s.s_id');
        return $query->result();
    }
    public function Get_ti($pid,$sid)
    {
         $query=$this->db->query("select t_id from tbl_timetable1 where p_id=$pid and sem_id=$sid");
         return $query->result();
    }
    public function SelectProgram($tid)
    {
        $query=$this->db->query("select time1,time2,d_name,f_nname,s_code,c_name ,type from tbl_timetable1 tt,tbl_subjectallocation sa,tbl_faculty f,tbl_subject s,tbl_day d,tbl_class c,tbl_subjecttime st where tt.d_id =d.d_id  and tt.sa_id =sa.sa_id  and sa.s_id=s.s_id and st.c_id=c.c_id and f.f_id=sa.f_id");
        /*foreach ($query->result() as $row)
        {
            //echo $row->p_id;
            echo $row->time1;
            echo $row->time2;
            echo $row->monday;
        }*/
        return $query->result();
    }
    public function Sem_id()
    {
        $query=$this->db->query("select max(st_id) as st_id from tbl_subjecttime");
        //$query = $this->db->select('max(st_id) as st_id')->from('tbl_subjecttime')->get();
       // print(json_encode($query->result()));
        foreach($query->result() as $row)
        {
            $st_id=$row->st_id+1;
        }
        return $st_id;
    }
    public function Sa_id()
    {
        $query=$this->db->query("select max(sa_id) as sa_id from tbl_subjectallocation");
        //$query = $this->db->select('max(st_id) as st_id')->from('tbl_subjecttime')->get();
       // print(json_encode($query->result()));
        foreach($query->result() as $row)
        {
            $sa_id=$row->sa_id+1;
        }
        return $sa_id;
    }
    public function Get_suballo()
    {
        $query=$this->db->get('tbl_subjectallocation');
        return $query->result();
    }
    //id search below
    public function Get_facultydetails($fid)
    {
        $query=$this->db->query("select * from tbl_faculty where f_id=$fid");
        return $query->result();
    }
    public function Get_programdetails($pid)
    {
        $query=$this->db->query("select * from tbl_program where p_id=$pid");
        return $query->result();
    }
    public function Get_semesterdetails($semid)
    {
        $query=$this->db->query("select * from tbl_semester where sem_id=$semid");
        return $query->result();
    }
    public function Get_subjectdetails($sid)
    {
        $query=$this->db->query("select * from tbl_subject where s_id=$sid");
        return $query->result();
    }
    public function Get_subjectallocation($pid,$semid,$fid,$sid)
    {
        $query=$this->db->query("select p_name,semester,f_name,f_nname,s_code,s_name from tbl_program p,tbl_semester sem,tbl_faculty f,tbl_subject s where p.p_id = $pid and sem.sem_id = $semid and f.f_id=$fid and s.s_id=$sid;");
        return $query->result();
    }
    //insert in timetable1 from time table allocation 
    public function Insert_Suballocation($sa_id,$pid,$semid,$fid,$sid)
    {
        $query=$this->db->query("select count(f_id) as f_id from tbl_subjectallocation where f_id=$fid");
        foreach($query->result() as $row)
        {
            $f_id=$row->f_id+1;
        }
        //return $sa_id;
        if($f_id<=2)
        {
            $query=$this->db->query("insert into tbl_subjectallocation values($sa_id,$pid,$semid,$fid,$sid,'yes')");
            if($query)
            {
                echo '<script type="text/javascript">';
                echo "alert('record inserted');";
                echo "window.location.href='http://localhost/CodeIgniter/index.php/TimeTable_con/Faculty/';";
                echo "</script>";
            }
        }
            else
            {
                echo '<script type="text/javascript">';
                echo "alert('faculty has already 2 subject to teach');";
                //echo "window.location.href='http://localhost/CodeIgniter/index.php/TimeTable_con/Faculty/';";
                echo "</script>";  
            }
    }
    public function TimeTableid()
    {
        $query=$this->db->query("select max(t_id) as t_id from tbl_timetable1");
        //$query = $this->db->select('max(st_id) as st_id')->from('tbl_subjecttime')->get();
       // print(json_encode($query->result()));
        foreach($query->result() as $row)
        {
            $t_id=$row->t_id+1;
        }
        return $t_id;
    }
    public function Insert_Sem($st_id,$sa_id,$c_id,$type)
    {
        $query=$this->db->query("insert into tbl_subjecttime values($st_id,$sa_id,$c_id,'$type','yes')");
        if($query)
        {
          echo '<script type="text/javascript">';
          echo "alert('record inserted');";
          //echo "window.location.href='http://localhost/CodeIgniter/index.php/login_con/';";
          echo "</script>";
        }
    }
    public function Insert_TimeTable($t_id,$pid,$semid,$time1,$time2,$day,$sa_id)
    {
        $query=$this->db->query("insert into tbl_timetable1 values($t_id,$pid,$semid,'$time1','$time2','$day',$sa_id,'yes')");
        if($query)
        {
          echo '<script type="text/javascript">';
          echo "alert('record inserted');";
          //echo "window.location.href='http://localhost/CodeIgniter/index.php/login_con/';";
          echo "</script>";
        }
        
       
    }
    public function GetTimedata($pid,$sid)
    {
        $query=$this->db->query("select t_id,time1,time2,day,f_nname,s_code,s_name,type,c_name from tbl_timetable1 tt,tbl_subjectallocation sa,tbl_faculty f,tbl_subject s,tbl_subjecttime st,tbl_class c where sa.f_id=f.f_id and sa.s_id=s.s_id and st.st_id=tt.st_id and st.c_id=c.c_id and tt.sem_id=sa.sem_id  and sa.sa_id=st.sa_id and sa.sem_id=tt.sem_id and sa.p_id=tt.p_id and tt.p_id='$pid' and tt.sem_id='$sid'");
        return $query->result();
    }
    public function GetSubAllo($sa_id)
    {
        $query=$this->db->query("select * from tbl_timetable1 where p_id=$pid and sem_id=$sid");
        return $query->result();
    }
    public function insertsub($sid,$scode,$sname)
    {
        $query=$this->db->query("insert into tbl_subject values($sid,'$scode','$sname','yes')");
        if($query)
        {
          echo '<script type="text/javascript">';
          echo "alert('subject inserted');";
          //echo "window.location.href='http://localhost/CodeIgniter/index.php/login_con/';";
          echo "</script>";
        }
    }
    public function Get_sem()
    {
        $query=$this->db->query("select max(s_id) as s_id from tbl_subject");
        foreach($query->result() as $row)
        {
            $s_id=$row->s_id+1;
        }
        return $s_id;
    }
    public function deletefs($said)
    {

        $query=$this->db->query("delete from tbl_subjectallocation where sa_id='$said'");
        if($query)
        {
          echo '<script type="text/javascript">';
          echo "alert('Deleted');";
          echo "window.location.href='http://localhost/CodeIgniter/index.php/TimeTable_con/Faculty/';";
          echo "</script>";
        }
    }
    public function GetFacultyTime($fid)
    {
        $query=$this->db->query("select t_id,time1,time2,day,f_nname,f_name,s_code,type,c_name,p_name from tbl_timetable1 tt,tbl_subjectallocation sa,tbl_faculty f,tbl_subject s,tbl_subjecttime st,tbl_class c,tbl_program p where p.p_id=sa.p_id and sa.f_id=f.f_id and sa.s_id=s.s_id and st.st_id=tt.st_id and st.c_id=c.c_id and tt.sem_id=sa.sem_id  and sa.sa_id=st.sa_id and sa.sem_id=tt.sem_id and sa.p_id=tt.p_id and sa.f_id=$fid");
        return $query->result();
    }
    public function facultyLoad($fid)
    {
        $query=$this->db->query("select count(t_id) as l_count from tbl_timetable1 tt,tbl_subjectallocation sa,tbl_faculty f,tbl_subject s,tbl_subjecttime st,tbl_class c,tbl_program p where p.p_id=sa.p_id and sa.f_id=f.f_id and sa.s_id=s.s_id and st.st_id=tt.st_id and st.c_id=c.c_id and tt.sem_id=sa.sem_id  and sa.sa_id=st.sa_id and sa.sem_id=tt.sem_id and sa.p_id=tt.p_id and sa.f_id=$fid");
        return $query->result();  
    }
    /*public function GetFacultyTime_p($fid,$per_page,$page)
    {
        $query=$this->db->query("select t_id,time1,time2,day,f_nname,f_name,s_code,type,c_name,p_name from tbl_timetable1 tt,tbl_subjectallocation sa,tbl_faculty f,tbl_subject s,tbl_subjecttime st,tbl_class c,tbl_program p where p.p_id=sa.p_id and sa.f_id=f.f_id and sa.s_id=s.s_id and st.st_id=tt.st_id and st.c_id=c.c_id and tt.sem_id=sa.sem_id  and sa.sa_id=st.sa_id and sa.sem_id=tt.sem_id and sa.p_id=tt.p_id and sa.f_id=$fid LIMIT $page,$per_page");
        return $query->result();    
    }*/
    public function GetFacultyTime_p($fid,$page)
    {
        $r=2;
        $offset = ($page-1)*$r;
        $query=$this->db->query("select t_id,time1,time2,day,f_nname,f_name,s_code,type,c_name,p_name from tbl_timetable1 tt,tbl_subjectallocation sa,tbl_faculty f,tbl_subject s,tbl_subjecttime st,tbl_class c,tbl_program p where p.p_id=sa.p_id and sa.f_id=f.f_id and sa.s_id=s.s_id and st.st_id=tt.st_id and st.c_id=c.c_id and tt.sem_id=sa.sem_id  and sa.sa_id=st.sa_id and sa.sem_id=tt.sem_id and sa.p_id=tt.p_id and sa.f_id=$fid LIMIT $offset,$r");
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
        return $data;
    }
    return false;
    }
}
