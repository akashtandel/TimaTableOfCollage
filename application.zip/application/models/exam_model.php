<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of exam_model
 *
 * @author HP
 */
class exam_model extends CI_Model{
    //put your code here
    public function insert_data($fname,$ffanme)
    {
        $query=$this->db->query("select max(f_id) as f_id from tbl_faculty");
        foreach ($query->result() as $row)
        {
            $f_id=$row->f_id;
        }
        $f_id=$f_id+1;
        //echo $f_id;
        
        $queryi=$this->db->query("insert into tbl_faculty values('$f_id','$fname','$ffanme','yes')");
        if($queryi)
        {
            echo '<script type="text/javascript">';
            echo "alert('record insertted');";
            echo "window.location.href='http://localhost/codeIgniter/index.php/exam_con/';";
            echo "</script>";
        }
        else
        {
            echo "check record";
        }
    }
    public function view_data()
    {
        $query=$this->db->query("select * from tbl_faculty");
        return $query->result();
        
    }
    public function deletef($f_id)
    {
        $query=$this->db->query("delete from tbl_faculty where f_id='$f_id'");
        if($query)
        {
            echo '<script type="text/javascript">';
            echo "alert('faculty deleted');";
            echo "window.location.href='http://localhost/codeIgniter/index.php/exam_con/';";
            echo "</script>";
        }
    }
}
