<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Login_model
 *
 * @author HP
 */
class Login_model extends CI_Model{
    //put your code here
    
    public function Index()
    {
        $query=$this->db->get('user');
        /*foreach ($query->result() as $row)
        {
            echo $row->name;
        }*/
        return $query->result();    
    }
    public function Insert($id,$name,$phone,$add)
    {
        $sql="insert into user values($id,'$name','$phone','$add')";
        $this->db->query($sql);
    }
    public function update($id)
    {
        //echo $id;
        $sqlup="update user set name='akash' where id='$id'";
        $this->db->query($sqlup);
        if($this->db->query($sqlup)>0)
        {
          echo '<script type="text/javascript">';
          echo "alert('Updated');";
          echo "window.location.href='http://localhost/CodeIgniter/index.php/login_con/';";
          echo "</script>";
        }
    }
    public function delete($id)
    {
        //echo $id;
        $sqlup="delete from user where id='$id'";
        $this->db->query($sqlup);
        if($this->db->query($sqlup)>0)
        {
          echo '<script type="text/javascript">';
          echo "alert('Deleted');";
          echo "window.location.href='http://localhost/CodeIgniter/index.php/login_con/';";
          echo "</script>";
        }
    }
}
