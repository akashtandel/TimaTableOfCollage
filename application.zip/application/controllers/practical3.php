<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of helper
 *
 * @author HP
 */
class Practical3 extends CI_Controller{
    //put your code here
    public function index() {
    $this->load->view("time_table");
  //  $this->load->helper('form');
//    $this->load->helper('');
    }
}
