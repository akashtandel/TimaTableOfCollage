<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of exam_con
 *
 * @author HP
 */
class exam_con extends CI_Controller{
    //put your code here
    public function index()
    {
        $this->load->view("exam_test");
        if($this->input->post("submit")!=NULL)
        {
            $fname=$this->input->post("fname");
            $ffname=$this->input->post("ffname");
            $this->load->model("exam_model");
            $this->exam_model->insert_data($fname,$ffname);
        }
        if($this->input->post("view")!=NULL)
        {
            $this->load->model("exam_model");
            $data['f_data']=$this->exam_model->view_data();
            $this->load->view("show_data",$data);
        }
        
    }
    public function delete($f_id=NULL)
    {
        $this->load->model("exam_model");
        $this->exam_model->deletef($f_id);
    }
}
