<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of login_con
 *
 * @author HP
 */
class login_con extends CI_Controller{
    //put your code here
    public function index() {
        //$this->load->view("login_view");
        $this->load->view("home");
        
        if($this->input->post('submit')!=NULL)
        {
             $id=$this->input->post('txtid');
             $name=$this->input->post('txtname');
             $phone=$this->input->post('txtphone');
             $add=$this->input->post('txtadd');
            $this->load->model("Login_model");
            $this->Login_model->Insert($id,$name,$phone,$add);
        }
    }
    public function Display()
    {
        $this->load->model("Login_model");
        $data['data']=$this->Login_model->Index();
        $this->load->view('display',$data);
    }
    public function update($id=NULL)
    {
        $this->load->model("Login_model");
        $this->Login_model->update($id);
    }
    public function delete($id=NULL)
    {
        $this->load->model("Login_model");
        $this->Login_model->delete($id);
    }
}