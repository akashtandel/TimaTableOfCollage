<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TimeTable_con
 *
 * @author HP
 */
class TimeTable_con extends CI_Controller{
    //put your code here
    public function Index()
    {       
        $this->load->view('TimeHome');
        //$this->load->view('home_s');
        $this->load->model("TimeTable");
        $data['pdata']=$this->TimeTable->Program();
        $data['sdata']=$this->TimeTable->Semester();
        $data['cndata']=$this->TimeTable->Subjectcn();
        $data['fdata']=$this->TimeTable->Faculty();
        $data['cdata']=$this->TimeTable->Clas();
        $data['sadata']=$this->TimeTable->Subjectallocation();
       // $data=array($pdata=$this->TimeTable->Program(),$sdata=$this->TimeTable->Semester());
        $this->load->view('home_s',$data);
        if($this->input->post('insert_semester')!=NULL)
        {
            $pid=$this->input->post('pid');
            $semid=$this->input->post('sid');
            $sa_id=$this->input->post('said');
            $c_id=$this->input->post('cid');
            //$subcode=$this->input->post('scode');
            $day=$this->input->post('day');
            $time1=$this->input->post('time1');
            $time2=$this->input->post('time2');
            $type=$this->input->post('type');
            $this->load->model("TimeTable");
            $st_id=$this->TimeTable->Sem_id();
            $t_id=$this->TimeTable->TimeTableid();
            $this->TimeTable->Insert_Sem($st_id,$sa_id,$c_id,$type); 
            $this->TimeTable->Insert_TimeTable($t_id,$pid,$semid,$time1,$time2,$day,$st_id); 

        }
       
    }
    public function Faculty()
    {       
        $this->load->view('TimeHome');
        $this->load->model("TimeTable");
        $data['pdata']=$this->TimeTable->Program();
        $data['sdata']=$this->TimeTable->Semester();
        $data['cndata']=$this->TimeTable->Subjectcn();
        $data['fdata']=$this->TimeTable->Faculty();
        $this->load->view('subject_allocation',$data);
        if($this->input->post('subject_allocation')!=NULL)
        {
            $pid=$this->input->post('pid');
            $semid=$this->input->post('semid');
            $fid=$this->input->post('fid');
            $sid=$this->input->post('sid');
            $this->load->model("TimeTable");
            $sa_id=$this->TimeTable->Sa_id();
            $this->TimeTable->Insert_Suballocation($sa_id,$pid,$semid,$fid,$sid); 

        }
        //$this->load->helper('form');
        
        if($this->input->post('load_form')) 
        {
            $this->load->model("TimeTable");
            $this->load->view("faculty_subject");
            $data['sadata']=$this->TimeTable->Get_suballo();
            foreach($this->TimeTable->Get_suballo() as $sakey)
            {
                $sa_id=$sakey->sa_id;
                $pid=$sakey->p_id;
                $semid=$sakey->sem_id;
                $fid=$sakey->f_id;
                $sid=$sakey->s_id;
                //$data['sdata']=$this->TimeTable->Get_subjectallocation($pid,$semid,$fid,$sid);
                foreach($this->TimeTable->Get_subjectallocation($pid,$semid,$fid,$sid) as $skey)
                {
                    $p_name=$skey->p_name;
                    $semester=$skey->semester;
                    $f_name=$skey->f_name;
                    $f_nname=$skey->f_nname;
                    $s_code=$skey->s_code;
                    $s_name=$skey->s_name; 
                    //echo "<br>";
                    $data['sdata']=array('sid'=>$sa_id,'f_nname'=>$f_nname,'p_name'=>$p_name,'sem'=>$semester,'scode'=>$s_code,'sname'=>$s_name);
                }
                $this->load->view("faculty_subject1",$data);
                /*echo "<pre>";
                print_r($data['sdata']);
                echo "</pre>";*/
            }
        }
        
    }
    public function Display()
    {
       $this->load->view('TimeHome');
       $this->load->model("TimeTable");
       
       $data['sdata']=$this->TimeTable->Semester();
       $data['pdata']=$this->TimeTable->Program();
       $this->load->view('Sprogram',$data);

       if($this->input->post('sp')!=NULL)
        {
           
            $pid=$this->input->post('pid');
            $sid=$this->input->post('sid');
            $this->load->model("TimeTable");
            foreach($this->TimeTable->Get_programdetails($pid) as $pkey)
            {
                $p_name=$pkey->p_name;
            }
            foreach($this->TimeTable-> Get_semesterdetails($sid) as $skey)
            {
                $semester=$skey->semester;
            }
            $data['program']=array('p_name'=>$p_name);
            $data['sem']=array('semester'=>$semester);
            $mt1=$mt2=$mt3=$mt4=$mt5=$mt6=$mt7="";
            $mon1=$mon2=$mon3=$mon4=$mon5=$mon6=$mon7="";
            $tut1=$tut2=$tut3=$tut4=$tut5=$tut6=$tut7="";
            $tue1=$tue2=$tue3=$tue4=$tue5=$tue6=$tue7="";
            $wt1=$wt2=$wt3=$wt4=$wt5=$wt6=$wt7="";
            $wed1=$wed2=$wed3=$wed4=$wed5=$wed6=$wed7="";
            $tht1=$tht2=$tht3=$tht4=$tht5=$tht6=$tht7="";
            $thu1=$thu2=$thu3=$thu4=$thu5=$thu6=$thu7="";
            $frt1=$frt2=$frt3=$frt4=$frt5=$frt6=$frt7="";
            $fri1=$fri2=$fri3=$fri4=$fri5=$fri6=$fri7="";
            $sat1=$st1="";

            foreach($this->TimeTable->GetTimedata($pid,$sid) as $tkey)
            {
                $tid=$tkey->t_id;
                $time1=$tkey->time1;
                $time2=$tkey->time2;
                $day=$tkey->day;
                $f_nname=$tkey->f_nname;
                $s_code=$tkey->s_code;
                $s_name=$tkey->s_name;
                $type=$tkey->type;
                $c_name=$tkey->c_name;
                
                //$data['tdata']=array('tid'=>$tid,'time1'=>$time1,'time2'=>$time2,'day'=>$day,'f_nname'=>$f_nname,'s_code'=>$s_code,'s_name'=>$s_name,'type'=>$type,'c_name'=>$c_name);
                if($time1=="08:30" && $time2=="09:25")
                {
                    if($day=="monday")
                    {
                        $mon1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt1="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut1="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt1="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht1="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt1="orange";
                        }
                    }
                    if($day=="saturday")
                    {
                        $sat1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $st1="orange";
                        }
                    }
                }
                if($time1=="09:25" && $time2=="10:20")
                {
                    if($day=="monday")
                    {
                        $mon2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt2="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut2="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt2="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht2="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt2="orange";
                        }
                    }

                }
                if($time1=="10:20" && $time2=="11:15")
                {
                    if($day=="monday")
                    {
                        $mon3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt3="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut3="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt3="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht3="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt3="orange";
                        }
                    }
                }
                if($time1=="11:55" && $time2=="12:50")
                {
                    if($day=="monday")
                    {
                        $mon4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt4="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut4="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt4="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht4="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt4="orange";
                        }
                    }
                }
                if($time1=="12:50" && $time2=="01:45")
                {
                    if($day=="monday")
                    {
                        $mon5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt5="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut5="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt5="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht5="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt5="orange";
                        }
                    }
                }
                if($time1=="01:55" && $time2=="02:50")
                {
                    if($day=="monday")
                    {
                        $mon6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt6="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut6="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt6="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht6="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt6="orange";
                        }
                    }
                }
                if($time1=="02:50" && $time2=="03:45")
                {
                    if($day=="monday")
                    {
                        $mon7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt7="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut7="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt7="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht7="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt7="orange";
                        }
                    }
                }
                $data['table']=array("mon1"=>$mon1,"tue1"=>$tue1,"wed1"=>$wed1,"thu1"=>$thu1,"fri1"=>$fri1,"sat1"=>$sat1,"mon2"=>$mon2,"tue2"=>$tue2,"wed2"=>$wed2,"thu2"=>$thu2,"fri2"=>$fri2,"mon3"=>$mon3,"tue3"=>$tue3,"wed3"=>$wed3,"thu3"=>$thu3,"fri3"=>$fri3,"mon4"=>$mon4,"tue4"=>$tue4,"wed4"=>$wed4,"thu4"=>$thu4,"fri4"=>$fri4,"mon5"=>$mon5,"tue5"=>$tue5,"wed5"=>$wed5,"thu5"=>$thu5,"fri5"=>$fri5,"mon6"=>$mon6,"tue6"=>$tue6,"wed6"=>$wed6,"thu6"=>$thu6,"fri6"=>$fri6,"mon7"=>$mon7,"tue7"=>$tue7,"wed7"=>$wed7,"thu7"=>$thu7,"fri7"=>$fri7);
                $data['type']=array("mt1"=>$mt1,"mt2"=>$mt2,"mt3"=>$mt3,"mt4"=>$mt4,"mt5"=>$mt5,"mt6"=>$mt6,"mt7"=>$mt7,"tut1"=>$tut1,"tut2"=>$tut2,"tut3"=>$tut3,"tut4"=>$tut4,"tut5"=>$tut5,"tut6"=>$tut6,"tut7"=>$tut7,"wt1"=>$wt1,"wt2"=>$wt2,"wt3"=>$wt3,"wt4"=>$wt4,"wt5"=>$wt5,"wt6"=>$wt6,"wt7"=>$wt7,"tht1"=>$tht1,"tht2"=>$tht2,"tht3"=>$tht3,"tht4"=>$tht4,"tht5"=>$tht5,"tht6"=>$tht6,"tht7"=>$tht7,"frt1"=>$frt1,"frt2"=>$frt2,"frt3"=>$frt3,"frt4"=>$frt4,"frt5"=>$frt5,"frt6"=>$frt6,"frt7"=>$frt7,"st1"=>$st1,);
                //print_r($data['type']);
                //$this->load->view("TimeTable2",$data);
                
            }
            $this->load->view("TimeTable2",$data);
        }
        
    }
    public function Subject()
    {
        $this->load->view("TimeHome");
        $this->load->view("subject");
        if($this->input->post('subject')!=NULL)
        {
            $scode=$this->input->post('scode');
            $sname=$this->input->post('sname');
            $this->load->model("TimeTable");
            $sid=$this->TimeTable->Get_sem();
            $this->TimeTable->Insertsub($sid,$scode,$sname);
        }
        
    }
    public function deletefs($said=NULL)
    {
        $this->load->model("TimeTable");
        $this->TimeTable->deletefs($said);  
    }
    public function FacultyTime()
    {
        $this->load->view("TimeHome");
        $this->load->model("TimeTable");
        $data['fdata']=$this->TimeTable->Faculty();
        $this->load->view("SelectFaculty",$data);
        if($this->input->post('faculty')!=NULL)
        {
            $fid=$this->input->post("fid");
            $this->load->model("TimeTable");
            $mt1=$mt2=$mt3=$mt4=$mt5=$mt6=$mt7="";
            $mon1=$mon2=$mon3=$mon4=$mon5=$mon6=$mon7="";
            $tut1=$tut2=$tut3=$tut4=$tut5=$tut6=$tut7="";
            $tue1=$tue2=$tue3=$tue4=$tue5=$tue6=$tue7="";
            $wt1=$wt2=$wt3=$wt4=$wt5=$wt6=$wt7="";
            $wed1=$wed2=$wed3=$wed4=$wed5=$wed6=$wed7="";
            $tht1=$tht2=$tht3=$tht4=$tht5=$tht6=$tht7="";
            $thu1=$thu2=$thu3=$thu4=$thu5=$thu6=$thu7="";
            $frt1=$frt2=$frt3=$frt4=$frt5=$frt6=$frt7="";
            $fri1=$fri2=$fri3=$fri4=$fri5=$fri6=$fri7="";
            $sat1=$st1="";
            foreach($this->TimeTable->GetFacultyTime($fid) as $fkey)
            {
                $tid=$fkey->t_id;
                $time1=$fkey->time1;
                $time2=$fkey->time2;
                $day=$fkey->day;
                $f_nname=$fkey->p_name;
                $f_name=$fkey->f_name;
                $s_code=$fkey->s_code;
                //$s_name=$fkey->s_name;
                $type=$fkey->type;
                $c_name=$fkey->c_name;
                $p_name=$fkey->p_name;
                
                //$data['tdata']=array('tid'=>$tid,'time1'=>$time1,'time2'=>$time2,'day'=>$day,'f_nname'=>$f_nname,'s_code'=>$s_code,'s_name'=>$s_name,'type'=>$type,'c_name'=>$c_name);
                if($time1=="08:30" && $time2=="09:25")
                {
                    if($day=="monday")
                    {
                        $mon1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt1="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut1="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt1="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht1="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt1="orange";
                        }
                    }
                    if($day=="saturday")
                    {
                        $sat1=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $st1="orange";
                        }
                    }
                }
                if($time1=="09:25" && $time2=="10:20")
                {
                    if($day=="monday")
                    {
                        $mon2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt2="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut2="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt2="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht2="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri2=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt2="orange";
                        }
                    }

                }
                if($time1=="10:20" && $time2=="11:15")
                {
                    if($day=="monday")
                    {
                        $mon3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt3="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut3="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt3="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht3="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri3=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt3="orange";
                        }
                    }
                }
                if($time1=="11:55" && $time2=="12:50")
                {
                    if($day=="monday")
                    {
                        $mon4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt4="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut4="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt4="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht4="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri4=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt4="orange";
                        }
                    }
                }
                if($time1=="12:50" && $time2=="01:45")
                {
                    if($day=="monday")
                    {
                        $mon5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt5="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut5="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt5="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht5="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri5=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt5="orange";
                        }
                    }
                }
                if($time1=="01:55" && $time2=="02:50")
                {
                    if($day=="monday")
                    {
                        $mon6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt6="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut6="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt6="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht6="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri6=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt6="orange";
                        }
                    }
                }
                if($time1=="02:50" && $time2=="03:45")
                {
                    if($day=="monday")
                    {
                        $mon7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $mt7="orange";
                        }
                    }
                    if($day=="tuesday")
                    {
                        $tue7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tut7="orange";
                        }
                    }
                    if($day=="wednesday")
                    {
                        $wed7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $wt7="orange";
                        }
                    }
                    if($day=="thursday")
                    {
                        $thu7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $tht7="orange";
                        }
                    }
                    if($day=="friday")
                    {
                        $fri7=$s_code." ".$type."<br>".$f_nname."<br>".$c_name;
                        if($type=="P")
                        {
                            $frt7="orange";
                        }
                    }
                }
                $data['table']=array("f_name"=>$f_name,"mon1"=>$mon1,"tue1"=>$tue1,"wed1"=>$wed1,"thu1"=>$thu1,"fri1"=>$fri1,"sat1"=>$sat1,"mon2"=>$mon2,"tue2"=>$tue2,"wed2"=>$wed2,"thu2"=>$thu2,"fri2"=>$fri2,"mon3"=>$mon3,"tue3"=>$tue3,"wed3"=>$wed3,"thu3"=>$thu3,"fri3"=>$fri3,"mon4"=>$mon4,"tue4"=>$tue4,"wed4"=>$wed4,"thu4"=>$thu4,"fri4"=>$fri4,"mon5"=>$mon5,"tue5"=>$tue5,"wed5"=>$wed5,"thu5"=>$thu5,"fri5"=>$fri5,"mon6"=>$mon6,"tue6"=>$tue6,"wed6"=>$wed6,"thu6"=>$thu6,"fri6"=>$fri6,"mon7"=>$mon7,"tue7"=>$tue7,"wed7"=>$wed7,"thu7"=>$thu7,"fri7"=>$fri7);
                $data['type']=array("mt1"=>$mt1,"mt2"=>$mt2,"mt3"=>$mt3,"mt4"=>$mt4,"mt5"=>$mt5,"mt6"=>$mt6,"mt7"=>$mt7,"tut1"=>$tut1,"tut2"=>$tut2,"tut3"=>$tut3,"tut4"=>$tut4,"tut5"=>$tut5,"tut6"=>$tut6,"tut7"=>$tut7,"wt1"=>$wt1,"wt2"=>$wt2,"wt3"=>$wt3,"wt4"=>$wt4,"wt5"=>$wt5,"wt6"=>$wt6,"wt7"=>$wt7,"tht1"=>$tht1,"tht2"=>$tht2,"tht3"=>$tht3,"tht4"=>$tht4,"tht5"=>$tht5,"tht6"=>$tht6,"tht7"=>$tht7,"frt1"=>$frt1,"frt2"=>$frt2,"frt3"=>$frt3,"frt4"=>$frt4,"frt5"=>$frt5,"frt6"=>$frt6,"frt7"=>$frt7,"st1"=>$st1,);
                //print_r($data['type']);
                //$this->load->view("TimeTable2",$data);
            }
            $this->load->view("FacultyTimeTable",$data);
        }
    }
    public function FacultyLoad()
    {
        $this->load->view("TimeHome");
        $this->load->model("TimeTable");
        $data['fdata']=$this->TimeTable->Faculty();
        
        $this->load->view("SelectFaculty",$data);
        if($this->input->post('faculty')!=NULL)
        {
            $fid=$this->input->post("fid");
            $this->load->model("TimeTable");
            $l_count=$this->TimeTable->facultyLoad($fid);
            $data['fdata']=$this->TimeTable->Get_facultydetails($fid);
            foreach ($data['fdata'] as $fkey)
            {
            $f_name=$fkey->f_name;
            }
            foreach ($l_count as $lkey)
            {
                $l_count=$lkey->l_count;
            }
            echo $f_name." has total ".$l_count." lacture in week";
        }   
    }
    public function Pagination()
    {
        $this->load->view("TimeHome");
        $this->load->model("TimeTable");
        $data['fdata']=$this->TimeTable->Faculty();
        $this->load->helper('url');
        $this->load->library('pagination');
        $this->load->database();
        $this->load->view("SelectFaculty",$data);
        if($this->input->post('faculty')!=NULL)
        {
            $fid=$this->input->post("fid");
            $total_lacture=$this->TimeTable->facultyLoad($fid);
            foreach ($total_lacture as $tkey)
            {
                $total=$tkey->l_count;
            }
            //$per_page=2;
            $config =array();
            $config['base_url']="http://localhost/CodeIgniter/index.php/TimeTable_con/Pagination";
            $config['total_rows']=$total;

            /*$config['per_page']=2;
            $config['use_page_numbers'] = TRUE;
            $config['num_links'] = $total/2;
            $config['uri_segment']=3;*/
            $config["per_page"] = 2;
            $config['uri_segment']=3;
            $config['use_page_numbers'] = TRUE;
            $config['num_links'] = $total/2;
            $config['cur_tag_open'] = '&nbsp;<a class="current">';
            $config['cur_tag_close'] = '</a>';
            $this->pagination->initialize($config);
            if($this->uri->segment(3)===TRUE)
            {
               $page = $this->uri->segment(3) ;
            }
            else
            {
                $page = 1;
            }
            $data['results']=$this->TimeTable->GetFacultyTime_p($fid,$page);
            //print_r($data['results']);
            $str_links = $this->pagination->create_links();
            $data["links"] = explode('&nbsp;',$str_links );
            $this->load->view("pagination_1",$data);
        }      
     
    }
}